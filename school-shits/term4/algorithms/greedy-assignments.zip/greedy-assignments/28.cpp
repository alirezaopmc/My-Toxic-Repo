/*
A = 00
B = 011
Z = 0100
X = 0101
I = 10
S = 110
M = 111

011-00-0101-0101-0???
BAXX last char is not valid

10-00-10-00-0101-0???
IAIAX last char is not valid
*/
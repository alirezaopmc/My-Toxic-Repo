/*
size = 8

item a: w(5) v(5) => ratio = 1
item b: w(4) v(3) => ratio < 1
item c: w(4) v(3) => ratio < 1
*/
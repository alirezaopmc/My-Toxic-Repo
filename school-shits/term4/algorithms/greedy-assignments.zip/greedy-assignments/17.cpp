/*
Nope
vaghti ye vertex mark shod dg farz mishe shortest path barash ok shode
msln ye graph 3 raasi ro dar nazar begirid ke mosalas tashkil midan
e(0, 1) = 1
e(0, 2) = 2
e(2, 1) = -3

khob algortihm e(0,1) ro mibine ke 1 e va e(0,2) ke 2 e pas ba khodesh mige ke omran betoone az e(0, 2) be meghdare kamtaraz 1 berese
vali path(0, 2, 1) = 2-3 = -1 kamtar az 1 hazinash mishe
*/